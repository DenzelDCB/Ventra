import { collection, addDoc } from "firebase/firestore";
import { db } from "../firebase";

export async function seedMentors() {
  const mentorsRef = collection(db, "users");

  try {
    await addDoc(mentorsRef, {
      email: "alice@example.com",
      role: "mentor",
      skills: [
        "Software Engineer (Full Stack Developer)",
        "Software Engineer (Backend Developer)",
      ],
    });
    console.log("Added Alice");

    await addDoc(mentorsRef, {
      email: "bob@example.com",
      role: "mentor",
      skills: [
        "Software Engineer (Frontend Developer)",
        "Software Engineer (Backend Developer)",
      ],
    });
    console.log("Added Bob");

    await addDoc(mentorsRef, {
      email: "charlie@example.com",
      role: "mentor",
      skills: [
        "Software Engineer (Full Stack Developer)",
        "Software Engineer (Frontend Developer)",
      ],
    });
    console.log("Added Charlie");

    console.log("Mentors seeded successfully");
  } catch (error) {
    console.error("Error seeding mentors:", error);
  }
}
