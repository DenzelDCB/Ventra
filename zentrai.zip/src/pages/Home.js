// import Mentor from './mentor-dgrm.png'
import '../App.css'

function Home() {
  return (
    <div>
        {/* <div style={{textAlign: 'center',}}><img src={Mentor} alt="Mentor helping Mentee(s)" style={{width: '300px'}}></img></div> */}
        <div className='App'><h1>Learn a skill, publish a new project, accomplish your favorite career.</h1></div>
    </div>
  );
}

export default Home;